This is a port of an exercise from Coursera's course on Functional Reactive Programming.
